# hello_maven
This repo is contain spring boot hello world program for maven running application name "demo" with 8082 port
