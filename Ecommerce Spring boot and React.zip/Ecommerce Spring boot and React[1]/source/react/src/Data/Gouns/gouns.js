export const gounsPage1=[
    {
        "image": "https://www.amipetfood.com/site/assets/files/3102/apf-product-ami-dogs.516x387.jpg?t=1659387176",
        "brand": "A complete meal for adult dogs that is easy to digest.",
        "title": "",
        "color": "Blue",
        "selling_price": "₹466",
        "price": "₹999",
        "disscount": "53% off",
        "size": ""
    },
    {
        "image": "https://www.amipetfood.com/site/assets/files/3105/apf-product-ami-orange.516x387.jpg?t=1661442030",
        "brand": "Complete and balanced, perfect for your dog’s daily nutrition.",
        "title": "",
        "color": "Red",
        "selling_price": "₹449",
        "price": "₹1,099",
        "disscount": "59% off",
        "size": ""
    },
    {
        "image": "https://www.amipetfood.com/site/assets/files/3202/apf-product-ami-biscuits-vanilla.516x387.jpg?t=1659454171",
        "brand": "Vanilla-flavored biscuits: satisfying for their palate, crunchy.",
        "title": "",
        "color": "Beige",
        "selling_price": "₹298",
        "price": "₹1,599",
        "disscount": "81% off",
        "size": ""
    },
    {
        "image": "https://www.amipetfood.com/site/assets/files/3101/apf-product-ami-cats.516x387.jpg?t=1659389624",
        "brand": "Vegetable protein-based pet food, backed up by science.",
        "title": "",
        "color": "Beige",
        "selling_price": "₹298",
        "price": "₹1,599",
        "disscount": "81% off",
        "size": ""
    },
    {
        "image": "https://www.amipetfood.com/site/assets/files/3203/apf-product-ami-biscuits-seasonal-apple-and-cinnamon.516x387.jpg?t=1663086452",
        "brand": "Fall and Winter seasonal biscuits with apple and cinnamon.",
        "title": "",
        "color": "Light Green",
        "selling_price": "₹284",
        "price": "₹1,599",
        "disscount": "82% off",
        "size": ""
    },
    {
        "image": "https://m.media-amazon.com/images/I/51N2mLC3s9L._SL1100_.jpg",
        "brand": "Pedigree Adult Dry Dog Food, Chicken & Vegetables, 3kg Pack",
        "title": "",
        "color": "Dark Blue",
        "selling_price": "₹298",
        "price": "₹1,599",
        "disscount": "81% off",
        "size": ""
    }
]