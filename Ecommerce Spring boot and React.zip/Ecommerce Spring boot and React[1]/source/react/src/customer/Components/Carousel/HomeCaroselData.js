export const homeCarouselData=[
  {
      image:"https://www.petoly.in/cdn/shop/files/1903px_393px_9f6e624f-0d1e-421b-921c-e029185f6a39_1728x.jpg?v=1707198951",
      path:"/dogs/breed/alaskan_malamute"
  },
  {
      image:"https://www.petoly.in/cdn/shop/files/petoly_home_sliding_banners_31e78dea-cbb6-4704-9830-da0e2e56e40d_2048x.jpg?v=1704262587",
      path:"/dogs/breed/golden_retrievers"
  },
  {
      image:"https://www.petoly.in/cdn/shop/files/home_page_banner01_5eac8d00-61db-4175-9545-9f77dd2cf244_2048x.jpg?v=1700305047",
      path:"/dogs/breed/labrador_retrievers"
  }
  
]